  FOUND:
    libraries = ['mkl_intel_lp64', 'mkl_intel_thread', 'mkl_core', 'iomp5', 'pthread']
    library_dirs = ['/Users/filo/anaconda/lib']
    define_macros = [('SCIPY_MKL_H', None)]
    include_dirs = ['/Users/filo/anaconda/include']

UNKNOWN
License: UNKNOWN
Description: Use `scikit-learn <https://pypi.python.org/pypi/scikit-learn/>`_ instead.
Platform: all
